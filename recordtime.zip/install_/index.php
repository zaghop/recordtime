<?php
require_once('install.class.php');
$install = new Install();
$install->go();
