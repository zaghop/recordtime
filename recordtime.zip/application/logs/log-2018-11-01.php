<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-01 02:35:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 02:35:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 03:34:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 03:34:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 03:40:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 03:40:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 03:42:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 03:42:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 03:42:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 03:42:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:08:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:08:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:08:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:08:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:49:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:49:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:50:29 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-11-01 04:50:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:50:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:52:49 --> Could not find the language line "artists_overview"
ERROR - 2018-11-01 04:52:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:52:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:52:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:52:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:53:10 --> Could not find the language line "artists_overview"
ERROR - 2018-11-01 04:53:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:53:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:53:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:53:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:57:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:57:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:57:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:57:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:57:22 --> Could not find the language line "producers_overview"
ERROR - 2018-11-01 04:57:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:57:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:57:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:57:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:57:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:57:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:57:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:57:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:58:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:58:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:58:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:58:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:58:53 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-11-01 04:58:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:58:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:59:02 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-11-01 04:59:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:59:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:59:13 --> Could not find the language line "artists_overview"
ERROR - 2018-11-01 04:59:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:59:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 04:59:29 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-11-01 04:59:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 04:59:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 05:02:57 --> Could not find the language line "artists_overview"
ERROR - 2018-11-01 05:02:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 05:02:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 05:03:13 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-11-01 05:03:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 05:03:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 05:03:46 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-11-01 05:03:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 05:03:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 05:03:56 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-11-01 05:03:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 05:03:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 05:04:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 05:04:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 05:05:41 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-11-01 05:05:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 05:05:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 05:07:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 05:07:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 05:08:08 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-11-01 05:08:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 05:08:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 05:50:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 05:50:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 06:11:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 06:11:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 07:24:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 07:24:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 07:47:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 07:47:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 08:45:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 08:45:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 10:29:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 10:29:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 10:48:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 10:48:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 10:54:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 10:54:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 10:54:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 10:54:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-11-01 10:57:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-11-01 10:57:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
