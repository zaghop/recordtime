<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-09 01:11:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 01:11:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 01:14:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 01:14:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 01:14:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 01:14:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 02:59:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 02:59:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 04:31:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 04:31:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 04:31:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 04:31:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 04:31:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 04:31:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 06:00:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 06:00:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 07:54:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 07:54:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 08:25:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 08:25:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 08:35:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 08:35:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 08:36:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 08:36:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 08:37:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 08:37:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 08:41:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 08:41:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 09:01:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 09:01:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 09:21:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 09:21:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:10:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:10:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:10:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:10:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:10:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:10:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:10:55 --> Could not find the language line "producers_overview"
ERROR - 2018-10-09 10:10:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:10:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:10:56 --> Could not find the language line "artists_overview"
ERROR - 2018-10-09 10:10:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:10:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:14:35 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-09 10:14:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:14:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:14:37 --> Could not find the language line "artists_overview"
ERROR - 2018-10-09 10:14:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:14:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:14:39 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-09 10:14:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:14:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:14:41 --> Could not find the language line "producers_overview"
ERROR - 2018-10-09 10:14:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:14:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:27:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:27:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:27:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:27:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:27:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:27:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:28:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:28:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:28:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:28:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:28:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:28:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:28:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:28:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 10:36:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 10:36:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 12:10:37 --> Could not find the language line "artists_overview"
ERROR - 2018-10-09 12:10:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 12:10:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 12:22:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 12:22:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 00:35:44 --> 404 Page Not Found: Home/index
ERROR - 2018-10-09 13:26:25 --> Could not find the language line "producers_overview"
ERROR - 2018-10-09 13:26:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 13:26:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 14:02:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 14:02:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 14:02:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 14:02:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 14:02:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 14:02:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 02:00:11 --> 404 Page Not Found: Home/index
ERROR - 2018-10-09 14:42:12 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-09 14:42:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 14:42:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 14:56:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 14:56:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 15:07:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 15:07:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 15:57:59 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-09 15:57:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 15:57:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 05:10:29 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-09 05:43:49 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-09 06:17:09 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-09 18:57:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 18:57:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 20:39:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 20:39:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 08:09:36 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 20:45:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 20:45:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 20:45:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 20:45:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 20:45:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 20:45:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 08:51:49 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2018-10-09 21:21:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:21:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:21:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:21:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 08:51:50 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2018-10-09 21:21:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:21:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:21:51 --> Could not find the language line "producers_overview"
ERROR - 2018-10-09 21:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:21:51 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-09 21:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:21:51 --> Could not find the language line "artists_overview"
ERROR - 2018-10-09 21:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:21:52 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-09 21:21:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:21:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:25:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:25:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:29:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:29:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:29:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:29:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:29:22 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-09 21:29:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:29:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:29:23 --> Could not find the language line "artists_overview"
ERROR - 2018-10-09 21:29:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:29:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:29:23 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-09 21:29:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:29:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 21:29:23 --> Could not find the language line "producers_overview"
ERROR - 2018-10-09 21:29:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-09 21:29:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-09 11:31:37 --> 404 Page Not Found: Status/index
ERROR - 2018-10-09 11:31:51 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2018-10-09 11:31:51 --> 404 Page Not Found: _phpMyAdmin/scripts
ERROR - 2018-10-09 11:31:56 --> 404 Page Not Found: Admin/scripts
ERROR - 2018-10-09 11:31:59 --> 404 Page Not Found: Scripts/setup.php
ERROR - 2018-10-09 12:07:00 --> 404 Page Not Found: Home/index
ERROR - 2018-10-09 12:40:23 --> 404 Page Not Found: Home/index
ERROR - 2018-10-09 13:25:58 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-09 13:42:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 13:42:48 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 13:42:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 13:42:51 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 13:42:52 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 13:42:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-09 13:42:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-09 13:59:18 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-09 14:05:41 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:05:41 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:05:41 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:05:56 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:05:57 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:06:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:06:04 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:06:13 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:06:13 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:06:13 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:06:41 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:06:41 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:06:41 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:07:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:07:27 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:08:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:08:04 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:08:05 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:08:05 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:08:06 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:08:23 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:08:24 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:08:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:08:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:08:48 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:09:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:09:17 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:09:26 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:09:27 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:09:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:09:30 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:09:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:09:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:10 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:10:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:13 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:10:46 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:46 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:10:46 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-09 14:17:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:17:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:17:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:17:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:17:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 14:17:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:12:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:13:00 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-09 17:17:23 --> 404 Page Not Found: Get-started/index
ERROR - 2018-10-09 17:59:06 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2018-10-09 19:01:59 --> 404 Page Not Found: Status/index
ERROR - 2018-10-09 19:02:14 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2018-10-09 19:02:21 --> 404 Page Not Found: _phpMyAdmin/scripts
ERROR - 2018-10-09 19:02:22 --> 404 Page Not Found: Admin/scripts
ERROR - 2018-10-09 21:05:37 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-09 21:08:08 --> 404 Page Not Found: C5B10B44077/A0615919C635B
ERROR - 2018-10-09 21:10:17 --> 404 Page Not Found: Apple-icon-180x180png/index
ERROR - 2018-10-09 21:10:17 --> 404 Page Not Found: Apple-icon-180x180png/index
ERROR - 2018-10-09 21:36:40 --> 404 Page Not Found: Item/5314100178
ERROR - 2018-10-09 23:03:46 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-09 23:58:41 --> 404 Page Not Found: Home/index
