<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-23 00:19:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 00:19:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:19:04 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-23 00:19:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 00:19:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:19:05 --> Could not find the language line "producers_overview"
ERROR - 2018-10-23 00:19:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 00:19:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:19:06 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-23 00:19:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 00:19:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:19:07 --> Could not find the language line "artists_overview"
ERROR - 2018-10-23 00:19:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 00:19:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:19:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 00:19:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:32:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 00:32:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 01:14:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 01:14:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 01:14:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 01:14:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 01:14:18 --> Could not find the language line "artists_overview"
ERROR - 2018-10-23 01:14:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 01:14:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 02:53:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 02:53:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 02:59:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 02:59:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:18:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:18:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:35:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:35:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:35:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:35:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:35:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:35:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:35:15 --> Could not find the language line "artists_overview"
ERROR - 2018-10-23 03:35:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:35:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:35:16 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-23 03:35:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:35:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:35:17 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-23 03:35:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:35:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:35:18 --> Could not find the language line "producers_overview"
ERROR - 2018-10-23 03:35:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:35:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:35:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:35:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:41:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 03:41:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 04:36:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 04:36:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 04:56:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 04:56:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 05:45:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 05:45:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 08:15:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 08:15:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 08:17:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 08:17:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 08:17:49 --> Could not find the language line "artists_overview"
ERROR - 2018-10-23 08:17:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 08:17:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 08:17:52 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-23 08:17:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 08:17:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 08:17:54 --> Could not find the language line "producers_overview"
ERROR - 2018-10-23 08:17:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 08:17:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 08:17:57 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-23 08:17:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 08:17:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 08:21:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 08:21:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 09:01:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 09:01:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 09:13:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 09:13:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 10:05:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 10:05:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 10:40:23 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-23 10:40:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 10:40:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 10:46:04 --> Could not find the language line "artists_overview"
ERROR - 2018-10-23 10:46:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 10:46:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 10:50:26 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-23 10:50:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 10:50:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 10:53:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 10:53:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:05:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:05:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:24:36 --> Could not find the language line "producers_overview"
ERROR - 2018-10-23 11:24:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:24:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:26:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:26:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:26:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:26:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:26:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:26:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:26:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:26:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:26:28 --> Could not find the language line "artists_overview"
ERROR - 2018-10-23 11:26:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:26:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:26:28 --> Could not find the language line "producers_overview"
ERROR - 2018-10-23 11:26:28 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-23 11:26:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:26:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:26:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:26:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:26:28 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-23 11:26:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:26:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 11:49:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 11:49:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 12:30:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 12:30:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 12:42:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 12:42:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:22:19 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-23 00:23:17 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-23 13:11:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:11:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:41:26 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:26 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:11:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:11:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:41:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:11:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:11:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:41:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:33 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 00:41:33 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:34 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:34 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:11:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:11:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:41:35 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 00:41:35 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:35 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:11:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:11:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:41:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:40 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 00:41:41 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:41 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:11:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:11:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:41:42 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:42 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:43 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:11:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:11:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 13:11:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:11:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:41:44 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:44 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:45 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:45 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:41:46 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:12:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:12:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:42:02 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:12:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:12:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:42:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:12:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:12:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:42:28 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:29 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:29 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:12:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:12:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:42:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 13:12:34 --> Could not find the language line "producers_overview"
ERROR - 2018-10-23 13:12:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 13:12:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 00:42:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 00:42:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 01:59:05 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-23 02:32:25 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-23 15:08:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 15:08:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 02:38:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 02:39:01 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 02:39:09 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 15:09:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 15:09:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 02:39:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 02:39:33 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 15:29:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 15:29:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 15:29:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 15:29:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 15:29:11 --> Could not find the language line "artists_overview"
ERROR - 2018-10-23 15:29:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 15:29:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 15:29:12 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-23 15:29:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 15:29:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 15:29:12 --> Could not find the language line "producers_overview"
ERROR - 2018-10-23 15:29:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 15:29:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 15:29:13 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-23 15:29:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 15:29:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:05:37 --> 404 Page Not Found: Home/index
ERROR - 2018-10-23 15:58:36 --> Could not find the language line "producers_overview"
ERROR - 2018-10-23 15:58:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 15:58:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 03:28:39 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 03:33:22 --> 404 Page Not Found: Start/producer
ERROR - 2018-10-23 16:33:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 16:33:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 04:03:02 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-23 04:03:02 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-23 04:03:02 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-23 04:03:02 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-23 04:03:03 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 04:03:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-23 04:03:04 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-23 04:03:04 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-23 04:03:05 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-23 04:03:05 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-23 04:03:05 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 04:03:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-23 04:52:12 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-23 18:11:35 --> Could not find the language line "producers_overview"
ERROR - 2018-10-23 18:11:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 18:11:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 05:41:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 05:41:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 05:41:39 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 18:43:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 18:43:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 19:26:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 19:26:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 19:26:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 19:26:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 19:59:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 19:59:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 07:54:46 --> 404 Page Not Found: Start/artist
ERROR - 2018-10-23 20:40:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 20:40:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 08:10:52 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 08:20:32 --> 404 Page Not Found: Get-started/index
ERROR - 2018-10-23 22:00:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 22:00:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 22:01:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 22:01:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 23:13:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 23:13:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 23:21:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-23 23:21:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-23 12:12:14 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 12:12:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 12:12:16 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 12:32:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 12:32:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 12:32:08 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 13:01:33 --> 404 Page Not Found: CustomPage/342
ERROR - 2018-10-23 15:02:19 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 15:02:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 15:02:28 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 16:44:21 --> 404 Page Not Found: Custom-page-sitemapxml/index
ERROR - 2018-10-23 16:44:22 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-23 16:56:56 --> 404 Page Not Found: Home/index
ERROR - 2018-10-23 17:51:20 --> 404 Page Not Found: Artist/854199
ERROR - 2018-10-23 18:37:12 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-23 21:04:17 --> 404 Page Not Found: Home/index
ERROR - 2018-10-23 21:12:59 --> 404 Page Not Found: Manifestjson/index
ERROR - 2018-10-23 21:18:58 --> 404 Page Not Found: Happyphp/index
ERROR - 2018-10-23 23:14:53 --> 404 Page Not Found: Home/index
ERROR - 2018-10-23 23:50:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 23:50:34 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 23:50:35 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 23:50:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 23:50:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 23:50:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 23:50:38 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 23:54:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 23:54:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-23 23:54:17 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-23 23:54:31 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2018-10-23 23:54:37 --> 404 Page Not Found: User/register
ERROR - 2018-10-23 23:55:20 --> 404 Page Not Found: Assets/themes
