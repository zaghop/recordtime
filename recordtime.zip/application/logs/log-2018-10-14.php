<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-14 00:04:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 00:04:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 00:40:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 00:40:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 00:40:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 00:40:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 00:49:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 00:49:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 00:50:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 00:50:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 00:56:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 00:56:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 01:24:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 01:24:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 01:25:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 01:25:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 01:27:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 01:27:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 01:28:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 01:28:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 01:43:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 01:43:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 03:36:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 03:36:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:20:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 06:20:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:20:36 --> Could not find the language line "artists_overview"
ERROR - 2018-10-14 06:20:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 06:20:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:20:37 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-14 06:20:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 06:20:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:20:48 --> Could not find the language line "producers_overview"
ERROR - 2018-10-14 06:20:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 06:20:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:20:49 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-14 06:20:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 06:20:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 08:10:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 08:10:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 08:16:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 08:16:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 08:16:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 08:16:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 08:16:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 08:16:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 08:17:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 08:17:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 08:17:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 08:17:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 08:24:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 08:24:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 08:51:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 08:51:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 09:06:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 09:06:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 11:06:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 11:06:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 12:02:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 12:02:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 12:03:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 12:03:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 12:09:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 12:09:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 00:12:27 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-14 00:19:26 --> 404 Page Not Found: Item/5802000210
ERROR - 2018-10-14 13:13:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 13:13:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 01:40:54 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-14 14:13:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 14:13:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 01:43:14 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 14:35:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 14:35:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 02:14:14 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-14 14:44:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 14:44:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 02:14:24 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-14 02:14:24 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-14 02:14:24 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-14 02:14:25 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-14 02:14:26 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-14 02:14:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-14 02:14:26 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-14 02:14:27 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-14 02:14:27 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-14 02:14:27 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-14 02:14:27 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-14 02:14:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-14 14:46:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 14:46:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 14:51:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 14:51:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 15:07:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 15:07:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 15:10:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 15:10:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 03:37:46 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2018-10-14 16:07:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 16:07:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 03:37:47 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2018-10-14 16:07:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 16:07:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 17:17:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 17:17:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 04:47:54 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 04:47:55 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 05:21:20 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-14 05:41:21 --> 404 Page Not Found: Owa/index
ERROR - 2018-10-14 05:41:23 --> 404 Page Not Found: OWA/index
ERROR - 2018-10-14 05:41:24 --> 404 Page Not Found: Exchweb/bin
ERROR - 2018-10-14 18:57:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:57:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 18:57:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:57:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 18:57:47 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-14 18:57:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:57:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 18:57:52 --> Could not find the language line "artists_overview"
ERROR - 2018-10-14 18:57:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:57:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:27:53 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 18:58:00 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-14 18:58:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:58:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 18:58:12 --> Could not find the language line "producers_overview"
ERROR - 2018-10-14 18:58:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:58:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 18:58:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:58:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:28:13 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 18:58:14 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-14 18:58:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:58:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:28:14 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 18:58:15 --> Could not find the language line "artists_overview"
ERROR - 2018-10-14 18:58:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:58:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:28:15 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-14 18:58:15 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-14 18:58:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:58:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 18:58:27 --> Could not find the language line "producers_overview"
ERROR - 2018-10-14 18:58:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:58:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 18:58:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 18:58:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 06:28:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 19:15:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 19:15:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 20:32:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 20:32:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 08:02:24 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-14 08:02:24 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-14 08:02:25 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-14 08:02:25 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-14 08:02:28 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-14 08:02:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-14 08:02:29 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-14 08:02:29 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-14 08:02:29 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-14 08:02:29 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-14 08:02:30 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-14 08:02:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-14 20:42:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 20:42:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 21:56:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 21:56:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 09:26:24 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-14 09:26:24 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-14 09:26:25 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-14 09:26:25 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-14 09:26:25 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-14 09:26:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-14 09:26:26 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-14 09:26:26 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-14 09:26:26 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-14 09:26:27 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-14 09:26:27 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-14 09:26:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-14 22:31:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 22:31:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 10:01:12 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-14 10:01:12 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-14 10:01:12 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-14 10:01:13 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-14 10:01:13 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-14 10:01:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-14 10:01:14 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-14 10:01:14 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-14 10:01:14 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-14 10:01:15 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-14 10:01:15 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-14 10:01:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-14 22:45:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 22:45:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 10:56:26 --> 404 Page Not Found: Status/index
ERROR - 2018-10-14 10:56:33 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2018-10-14 23:37:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 23:37:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 23:37:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-14 23:37:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-14 11:32:28 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2018-10-14 11:32:28 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2018-10-14 11:57:51 --> 404 Page Not Found: Article/5635
ERROR - 2018-10-14 11:58:07 --> 404 Page Not Found: Home/index
ERROR - 2018-10-14 13:00:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 13:00:42 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 13:00:42 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 13:00:43 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 13:12:55 --> 404 Page Not Found: Key/ASWD56425CSA
ERROR - 2018-10-14 13:15:17 --> 404 Page Not Found: Key/ASWD56425CSA
ERROR - 2018-10-14 14:07:09 --> 404 Page Not Found: Key/ASWD56425CSA
ERROR - 2018-10-14 16:02:25 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 16:02:26 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 16:02:28 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 16:02:30 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-14 16:02:30 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-14 16:02:31 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 16:02:32 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-14 16:02:32 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-14 16:02:33 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-14 16:02:33 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-14 16:02:34 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 16:02:35 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-14 16:02:35 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 16:02:36 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-14 16:02:36 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-14 16:02:37 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-14 16:02:37 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-14 16:02:38 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 16:02:40 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-14 16:02:40 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-14 16:02:41 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-14 16:02:41 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-14 16:43:49 --> 404 Page Not Found: Home/index
ERROR - 2018-10-14 17:29:51 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-14 22:25:47 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-14 22:59:07 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-14 23:31:15 --> 404 Page Not Found: Privacy-policy/index
