<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-17 00:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 00:21:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 03:07:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 03:07:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 05:31:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 05:31:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 05:52:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 05:52:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 06:47:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 06:47:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 07:04:05 --> Could not find the language line "artists_overview"
ERROR - 2018-10-17 07:04:05 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 07:04:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 07:04:06 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-17 07:04:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 07:04:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 07:04:06 --> Could not find the language line "producers_overview"
ERROR - 2018-10-17 07:04:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 07:04:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 07:28:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 07:28:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 08:58:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 08:58:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 09:50:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 09:50:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 09:55:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 09:55:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 10:06:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 10:06:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 10:16:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 10:16:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 10:23:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 10:23:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 11:27:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 11:27:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 11:31:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 11:31:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 11:37:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 11:37:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 11:47:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 11:47:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 11:47:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 11:47:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 12:08:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 12:08:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 12:11:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 12:11:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 12:42:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 12:42:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 12:53:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 12:53:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 00:23:25 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-17 00:23:25 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-17 00:23:26 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-17 00:23:26 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-17 00:23:27 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-17 00:23:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-17 00:23:27 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-17 00:23:28 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-17 00:23:28 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-17 00:23:28 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-17 00:23:29 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-17 00:23:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-17 14:12:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 14:12:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 14:42:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 14:42:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 14:42:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 14:42:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 02:12:53 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 14:42:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 14:42:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 02:12:54 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 14:42:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 14:42:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 02:12:56 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 14:42:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 14:42:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 02:12:57 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 02:12:57 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 02:12:58 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 14:42:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 14:42:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 02:12:59 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-17 02:12:59 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-17 02:13:00 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 02:13:00 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 02:13:01 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 14:43:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 14:43:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 02:13:02 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-17 02:13:02 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 02:13:03 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-17 02:13:03 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-17 02:13:04 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 02:13:04 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 02:13:05 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 14:43:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 14:43:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 02:13:06 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-17 02:13:06 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 02:13:07 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-17 02:13:07 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-17 03:15:15 --> 404 Page Not Found: Get-started/index
ERROR - 2018-10-17 15:45:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 15:45:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 03:29:13 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-17 03:29:15 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-17 03:29:17 --> 404 Page Not Found: _phpMyAdmin/scripts
ERROR - 2018-10-17 03:29:19 --> 404 Page Not Found: Scripts/setup.php
ERROR - 2018-10-17 03:29:24 --> 404 Page Not Found: Pma/scripts
ERROR - 2018-10-17 03:29:26 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2018-10-17 16:00:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 16:00:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 16:23:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 16:23:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 03:53:58 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-17 03:53:58 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-17 03:53:59 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-17 03:53:59 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-17 03:53:59 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-17 03:54:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-17 03:54:00 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-17 03:54:00 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-17 03:54:00 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-17 03:54:01 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-17 03:54:01 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-17 03:54:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-17 04:02:35 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-17 04:02:35 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-17 04:02:36 --> 404 Page Not Found: _phpMyAdmin/scripts
ERROR - 2018-10-17 04:02:38 --> 404 Page Not Found: Scripts/setup.php
ERROR - 2018-10-17 04:02:39 --> 404 Page Not Found: Pma/scripts
ERROR - 2018-10-17 04:02:39 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2018-10-17 04:17:30 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-17 04:29:34 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-17 17:38:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 17:38:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 05:16:19 --> 404 Page Not Found: CustomPage/356
ERROR - 2018-10-17 18:16:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:16:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:16:28 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-17 18:16:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:16:28 --> Could not find the language line "artists_overview"
ERROR - 2018-10-17 18:16:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 05:46:28 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 18:16:30 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-17 18:16:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:16:30 --> Could not find the language line "producers_overview"
ERROR - 2018-10-17 18:16:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:16:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 05:46:31 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 18:16:31 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-17 18:16:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 05:46:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-17 18:16:32 --> Could not find the language line "artists_overview"
ERROR - 2018-10-17 18:16:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 05:46:32 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-17 18:16:33 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-17 18:16:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:16:33 --> Could not find the language line "producers_overview"
ERROR - 2018-10-17 18:16:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:16:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:16:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 05:46:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-17 18:21:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:21:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:22:10 --> Could not find the language line "artists_overview"
ERROR - 2018-10-17 18:22:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:22:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:22:10 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-17 18:22:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:22:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:22:26 --> Could not find the language line "producers_overview"
ERROR - 2018-10-17 18:22:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:22:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:22:27 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-17 18:22:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:22:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:49:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:49:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 18:50:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 18:50:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 19:09:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 19:09:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 19:09:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 19:09:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 06:39:52 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 19:09:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 19:09:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 06:39:53 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 19:09:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 19:09:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 06:39:54 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 19:09:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 19:09:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 06:39:56 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 06:39:56 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-17 06:39:56 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 06:39:57 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 19:09:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 19:09:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 06:39:58 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-17 06:39:59 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-17 06:39:59 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 06:40:00 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 06:40:01 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 19:10:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 19:10:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 06:40:02 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-17 06:40:03 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 06:40:03 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-17 06:40:04 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-17 06:40:04 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 06:40:05 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-17 06:40:05 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 19:10:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 19:10:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 06:40:07 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-17 06:40:07 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-17 06:40:08 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-17 06:40:08 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-17 20:08:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 20:08:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 20:08:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 20:08:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 20:54:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 20:54:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 21:29:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 21:29:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 09:01:12 --> 404 Page Not Found: Get-started/producer
ERROR - 2018-10-17 09:01:36 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-17 09:03:09 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-17 21:39:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 21:39:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 21:39:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 21:39:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 09:09:58 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-17 09:09:58 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-17 09:09:59 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-17 09:09:59 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-17 09:10:00 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-17 21:40:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 09:10:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-17 21:40:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 09:10:00 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-17 09:10:01 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-17 09:10:01 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-17 09:10:01 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-17 09:10:02 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-17 09:10:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-17 09:33:57 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-17 22:15:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 22:15:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 22:15:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 22:15:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 10:06:29 --> 404 Page Not Found: Start/songwriter
ERROR - 2018-10-17 22:50:09 --> Could not find the language line "artists_overview"
ERROR - 2018-10-17 22:50:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 22:50:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 22:50:19 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-17 22:50:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 22:50:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 22:50:19 --> Could not find the language line "producers_overview"
ERROR - 2018-10-17 22:50:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 22:50:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 22:50:20 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-17 22:50:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-17 22:50:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-17 11:35:38 --> 404 Page Not Found: Home/index
ERROR - 2018-10-17 11:50:37 --> 404 Page Not Found: Key/ASWD56425CSA
ERROR - 2018-10-17 15:19:30 --> 404 Page Not Found: Console/css
ERROR - 2018-10-17 15:35:11 --> 404 Page Not Found: Home/index
ERROR - 2018-10-17 15:55:39 --> 404 Page Not Found: Item/5314100178
ERROR - 2018-10-17 16:10:33 --> 404 Page Not Found: Start/producer
ERROR - 2018-10-17 16:18:27 --> 404 Page Not Found: Chart/60687
ERROR - 2018-10-17 17:43:47 --> 404 Page Not Found: Console/css
ERROR - 2018-10-17 17:43:49 --> 404 Page Not Found: Status/index
ERROR - 2018-10-17 18:18:08 --> 404 Page Not Found: Assets/stock
ERROR - 2018-10-17 20:12:44 --> 404 Page Not Found: Console/css
ERROR - 2018-10-17 20:12:45 --> 404 Page Not Found: Status/index
ERROR - 2018-10-17 21:09:39 --> 404 Page Not Found: Assets/stock
ERROR - 2018-10-17 21:22:40 --> 404 Page Not Found: Item/8203200201
ERROR - 2018-10-17 21:40:29 --> 404 Page Not Found: Assets/stock
ERROR - 2018-10-17 22:24:03 --> 404 Page Not Found: Home/index
ERROR - 2018-10-17 23:50:55 --> 404 Page Not Found: Splash_logogif/index
