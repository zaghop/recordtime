<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-26 00:01:41 --> Could not find the language line "artists_signup"
ERROR - 2018-11-26 00:01:41 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:01:41 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:01:44 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:01:44 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:01:44 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:02:50 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:02:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:02:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:02:51 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:02:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:02:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:03:55 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:03:55 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:03:55 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:04:07 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:04:07 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:04:07 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:04:14 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:04:14 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:04:14 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:04:28 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:04:28 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:04:28 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:04:33 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:04:33 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:04:33 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:04:43 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:04:43 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:04:43 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:04:52 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:04:52 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:04:52 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:06:29 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:06:29 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:06:29 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:06:44 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:06:44 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:06:44 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:07:09 --> Could not find the language line "artists_signup"
ERROR - 2018-11-26 00:07:09 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:07:09 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:13:27 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:13:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:13:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:13:35 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:13:35 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:13:35 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:13:35 --> Severity: Notice --> Undefined property: Website::$form_validation C:\xampp\htdocs\recordtime\application\controllers\Website.php 1430
ERROR - 2018-11-26 00:13:35 --> Severity: Error --> Call to a member function set_rules() on null C:\xampp\htdocs\recordtime\application\controllers\Website.php 1430
ERROR - 2018-11-26 00:14:13 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:14:13 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:14:13 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:14:13 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:14:13 --> Severity: Notice --> Undefined property: stdClass::$sEmail C:\xampp\htdocs\recordtime\application\models\User_model.php 43
ERROR - 2018-11-26 00:14:21 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:14:21 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:14:21 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:14:26 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:14:26 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:14:26 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:14:26 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:14:27 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:14:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:14:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:21:14 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:21:14 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:21:14 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:21:25 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:21:25 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:21:25 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:21:25 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:21:26 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:21:26 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:21:26 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:21:55 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:21:55 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:21:55 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:22:04 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:22:04 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:22:04 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:22:12 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:22:12 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:22:12 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:22:12 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:22:12 --> Severity: Notice --> Undefined property: stdClass::$sEmail C:\xampp\htdocs\recordtime\application\models\User_model.php 43
ERROR - 2018-11-26 00:22:14 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:22:14 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:22:14 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:22:18 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:22:18 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:22:18 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:22:18 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:22:18 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:22:18 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:22:18 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:22:55 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:22:55 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:22:55 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:23:00 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:23:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:23:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:23:00 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:23:00 --> Severity: Notice --> Undefined property: stdClass::$sEmail C:\xampp\htdocs\recordtime\application\models\User_model.php 44
ERROR - 2018-11-26 00:23:03 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:23:03 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:23:03 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:23:09 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:23:09 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:23:09 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:23:09 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:23:09 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:23:09 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:23:09 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:23:13 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:23:13 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:23:13 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:23:20 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:23:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:23:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:23:20 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:23:21 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:23:21 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:23:21 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:23:46 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:23:46 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:23:46 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:23:49 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:23:49 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:23:49 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:24:11 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:24:11 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:24:11 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:24:17 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:24:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:24:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:24:17 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:24:17 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:24:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:24:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:24:49 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:24:49 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:24:49 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:24:49 --> Severity: 8192 --> mysql_real_escape_string(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\recordtime\application\controllers\Website.php 1439
ERROR - 2018-11-26 00:25:03 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:25:03 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:25:03 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:25:20 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:25:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:25:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:25:24 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:25:24 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:25:24 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:25:24 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:25:24 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:25:24 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:25:44 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:25:44 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:25:44 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:25:51 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:25:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:25:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:25:51 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:25:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:25:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:26:27 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:26:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:26:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:26:37 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:26:37 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:26:37 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:26:37 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:26:37 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:26:37 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:26:48 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:26:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:26:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:26:48 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:26:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:26:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:26:58 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:26:58 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:26:58 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:26:59 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:26:59 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:26:59 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:27:10 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:27:10 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:27:10 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:27:15 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:27:15 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:27:15 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:27:16 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:27:16 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:27:16 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:29:32 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:29:32 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:29:32 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:30:42 --> Could not find the language line "artists_profile"
ERROR - 2018-11-26 00:30:42 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:30:42 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:31:43 --> Could not find the language line "artists_profile"
ERROR - 2018-11-26 00:31:43 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:31:43 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:31:47 --> Could not find the language line "artists_profile"
ERROR - 2018-11-26 00:31:47 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:31:47 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:31:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:31:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:32:30 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:32:30 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:33:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:33:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:33:20 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:33:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:33:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:33:48 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:33:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:33:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:33:48 --> Could not find the language line "artists_profile"
ERROR - 2018-11-26 00:33:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:33:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:34:06 --> Could not find the language line "artists_login"
ERROR - 2018-11-26 00:34:06 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:34:06 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:35:08 --> Could not find the language line "artists_profile"
ERROR - 2018-11-26 00:35:08 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:35:08 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:38:46 --> Could not find the language line "artists_profile"
ERROR - 2018-11-26 00:38:46 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:38:46 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-26 00:40:16 --> Could not find the language line "artists_profile"
ERROR - 2018-11-26 00:40:16 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-26 00:40:16 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
