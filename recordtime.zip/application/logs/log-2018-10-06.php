<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-06 01:52:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 01:52:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 01:52:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 01:52:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 02:30:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 02:30:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 02:33:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 02:33:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 03:47:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 03:47:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 04:37:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 04:37:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 04:51:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 04:51:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 05:28:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 05:28:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 06:05:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 06:05:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 06:40:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 06:40:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 08:26:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 08:26:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 08:58:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 08:58:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 09:18:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 09:18:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 09:52:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 09:52:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 09:52:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 09:52:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 09:52:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 09:52:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 09:52:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 09:52:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 09:52:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 09:52:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 10:12:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 10:12:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 12:28:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 12:28:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 12:28:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 12:28:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 00:34:34 --> 404 Page Not Found: Photo/326046:420
ERROR - 2018-10-06 13:43:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 13:43:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 13:58:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 13:58:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 14:02:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 14:02:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 14:03:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 14:03:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 15:28:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 15:28:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 03:05:35 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-06 03:06:25 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-06 03:21:19 --> 404 Page Not Found: Status/index
ERROR - 2018-10-06 17:23:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 17:23:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 04:53:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 04:53:10 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 04:53:11 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-06 04:53:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-06 18:26:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 18:26:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 05:56:56 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 05:56:56 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 05:56:56 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-06 19:40:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 19:40:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 19:57:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 19:57:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 07:54:38 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-06 21:47:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 21:47:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 09:17:28 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 09:17:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 09:17:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 09:17:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 09:17:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 09:17:33 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 09:48:16 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-06 10:01:08 --> 404 Page Not Found: CustomPage/358
ERROR - 2018-10-06 22:41:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 22:41:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 22:43:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 22:43:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 23:32:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 23:32:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 23:36:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 23:36:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 11:06:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 11:06:59 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 11:06:59 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 11:06:59 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 11:06:59 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-06 23:58:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-06 23:58:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-06 13:01:53 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-06 13:36:50 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 13:36:51 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 13:36:54 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 13:36:54 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 13:36:54 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 13:36:54 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-06 13:36:56 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-06 20:59:13 --> 404 Page Not Found: Status/index
ERROR - 2018-10-06 22:35:57 --> 404 Page Not Found: Home/index
