<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-13 00:26:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 00:26:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 01:03:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 01:03:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 01:36:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 01:36:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 01:36:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 01:36:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 01:56:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 01:56:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 02:59:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 02:59:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 03:27:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 03:27:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 05:06:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 05:06:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 05:06:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 05:06:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 05:12:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 05:12:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 05:33:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 05:33:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 06:23:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 06:23:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 08:20:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 08:20:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 08:20:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 08:20:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 08:21:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 08:21:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 08:56:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 08:56:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 08:56:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 08:56:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 09:13:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 09:13:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 10:05:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 10:05:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 10:55:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 10:55:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:04:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:04:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:05:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:05:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:22:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:22:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:22:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:22:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:22:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:22:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:22:26 --> Could not find the language line "artists_overview"
ERROR - 2018-10-13 12:22:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:22:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:22:27 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-13 12:22:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:22:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:22:28 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-13 12:22:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:22:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:22:29 --> Could not find the language line "producers_overview"
ERROR - 2018-10-13 12:22:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:22:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 12:22:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 12:22:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 13:17:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 13:17:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 00:47:14 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-13 00:47:14 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-13 00:47:15 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-13 00:47:15 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-13 00:47:16 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-13 00:47:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-13 00:47:16 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-13 00:47:17 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-13 00:47:17 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-13 00:47:17 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-13 00:47:18 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-13 00:47:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-13 13:52:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 13:52:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 14:19:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 14:19:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 14:53:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 14:53:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 02:24:52 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-13 14:55:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 14:55:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 15:04:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 15:04:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 02:45:26 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-13 03:03:25 --> 404 Page Not Found: Home/index
ERROR - 2018-10-13 03:17:29 --> 404 Page Not Found: Start/studio-professional
ERROR - 2018-10-13 03:18:46 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-13 15:49:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 15:49:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 15:49:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 15:49:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 18:31:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 18:31:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 18:37:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 18:37:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 18:37:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 18:37:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 06:07:32 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-13 18:37:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 18:37:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 06:07:32 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-13 18:37:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 18:37:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 06:07:33 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-13 18:37:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 18:37:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 06:07:33 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-13 06:07:33 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-13 06:07:33 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-13 18:37:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 18:37:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 06:07:34 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-13 06:07:34 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-13 06:07:34 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-13 06:07:34 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-13 06:07:34 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-13 18:37:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 18:37:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 19:36:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 19:36:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 19:36:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 19:36:45 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-13 19:36:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 19:36:46 --> Could not find the language line "artists_overview"
ERROR - 2018-10-13 19:36:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 07:06:46 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-13 19:36:47 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-13 19:36:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 19:36:48 --> Could not find the language line "producers_overview"
ERROR - 2018-10-13 19:36:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 19:36:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 07:06:48 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-13 19:36:49 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-13 19:36:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 07:06:49 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 19:36:49 --> Could not find the language line "artists_overview"
ERROR - 2018-10-13 19:36:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 07:06:49 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-13 19:36:49 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-13 19:36:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 19:36:50 --> Could not find the language line "producers_overview"
ERROR - 2018-10-13 19:36:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 19:36:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:36:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 07:06:51 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 19:52:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 19:52:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 20:56:41 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-13 20:56:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 20:56:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 20:59:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 20:59:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 21:48:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 21:48:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 09:18:51 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 09:19:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 22:23:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 22:23:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 22:32:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 22:32:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 10:41:00 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-13 23:22:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-13 23:22:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-13 11:34:46 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-13 11:34:47 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-13 11:34:47 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-13 11:34:47 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-13 11:34:48 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-13 11:34:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-13 11:34:49 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-13 11:34:49 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-13 11:34:50 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-13 11:34:50 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-13 11:34:51 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-13 11:34:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-13 12:19:23 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:19:24 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:19:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:19:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:19:26 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:19:26 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:57:11 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-13 12:57:12 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-13 12:57:13 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-13 12:57:14 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-13 12:57:15 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-13 12:57:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-13 12:57:16 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-13 12:57:17 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-13 12:57:17 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-13 12:57:18 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-13 12:57:18 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-13 12:57:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-13 12:58:28 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:58:29 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:58:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:58:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-13 12:58:30 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-13 15:23:55 --> 404 Page Not Found: Get-started/producer
ERROR - 2018-10-13 15:24:46 --> 404 Page Not Found: Terms/index
ERROR - 2018-10-13 17:48:57 --> 404 Page Not Found: Get-started/index
ERROR - 2018-10-13 18:40:51 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-13 19:06:16 --> 404 Page Not Found: Privacy-policy/index
ERROR - 2018-10-13 19:22:07 --> 404 Page Not Found: Env/index
ERROR - 2018-10-13 19:47:29 --> 404 Page Not Found: User/register
ERROR - 2018-10-13 20:42:18 --> 404 Page Not Found: Start/songwriter
ERROR - 2018-10-13 21:53:54 --> 404 Page Not Found: Store/index
ERROR - 2018-10-13 23:25:45 --> 404 Page Not Found: Artist-sitemapxml/3
ERROR - 2018-10-13 23:34:35 --> 404 Page Not Found: Css_php/index
