<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-24 00:42:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 00:42:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 00:49:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 00:49:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 01:02:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 01:02:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 01:05:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 01:05:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 01:59:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 01:59:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 02:29:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 02:29:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 03:32:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 03:32:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 03:42:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 03:42:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 04:41:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 04:41:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 08:05:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 08:05:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 10:08:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 10:08:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 11:06:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 11:06:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 11:37:27 --> Could not find the language line "producers_overview"
ERROR - 2018-10-24 11:37:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 11:37:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 11:49:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 11:49:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:08:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:08:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:20:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:20:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:20:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:20:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:20:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:20:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:20:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:20:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:24:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:24:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:24:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:24:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:24:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:24:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:24:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:24:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:24:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:24:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:24:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:24:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:25:19 --> Could not find the language line "artists_overview"
ERROR - 2018-10-24 12:25:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:25:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 12:33:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:33:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 00:03:42 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-24 00:03:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-24 00:03:48 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-24 12:53:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 12:53:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 13:00:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 13:00:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 00:30:32 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-24 00:30:32 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-24 00:30:33 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-24 00:30:33 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-24 00:30:34 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-24 00:30:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-24 00:30:34 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-24 00:30:34 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-24 00:30:35 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-24 00:30:35 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-24 00:30:35 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-24 00:30:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-24 13:01:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 13:01:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 14:18:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 14:18:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 01:48:58 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-24 01:57:35 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2018-10-24 01:57:39 --> 404 Page Not Found: Administrator/index.php
ERROR - 2018-10-24 01:57:42 --> 404 Page Not Found: Phpmyadmin/index.php
ERROR - 2018-10-24 01:57:45 --> 404 Page Not Found: Pma/index.php
ERROR - 2018-10-24 14:43:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 14:43:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 15:01:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 15:01:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 15:12:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 15:12:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 16:51:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 16:51:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 04:22:20 --> 404 Page Not Found: Home/index
ERROR - 2018-10-24 17:42:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 17:42:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 17:42:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 17:42:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 05:15:50 --> 404 Page Not Found: Custompage/342
ERROR - 2018-10-24 05:42:03 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-24 19:42:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 19:42:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 21:42:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 21:42:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 21:53:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 21:53:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 09:23:39 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-24 09:23:40 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-24 09:23:41 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-24 09:23:41 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-24 09:23:42 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-24 09:23:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-24 09:23:42 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-24 09:23:43 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-24 09:23:43 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-24 09:23:43 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-24 09:23:43 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-24 09:23:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-24 22:40:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 22:40:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 10:10:43 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-24 22:46:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 22:46:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 10:16:05 --> 404 Page Not Found: Wordpress/index
ERROR - 2018-10-24 10:16:06 --> 404 Page Not Found: Wp/index
ERROR - 2018-10-24 10:16:07 --> 404 Page Not Found: Blog/index
ERROR - 2018-10-24 10:16:07 --> 404 Page Not Found: New/index
ERROR - 2018-10-24 10:16:08 --> 404 Page Not Found: Old/index
ERROR - 2018-10-24 10:16:09 --> 404 Page Not Found: Test/index
ERROR - 2018-10-24 10:16:10 --> 404 Page Not Found: Main/index
ERROR - 2018-10-24 10:16:11 --> 404 Page Not Found: Site/index
ERROR - 2018-10-24 10:16:12 --> 404 Page Not Found: Backup/index
ERROR - 2018-10-24 10:16:12 --> 404 Page Not Found: Demo/index
ERROR - 2018-10-24 10:16:13 --> 404 Page Not Found: Home/index
ERROR - 2018-10-24 10:16:14 --> 404 Page Not Found: Tmp/index
ERROR - 2018-10-24 22:47:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 22:47:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 23:11:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-24 23:11:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-24 14:06:02 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-24 14:06:02 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-24 14:06:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-24 14:06:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-24 14:06:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-24 14:06:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-24 14:06:04 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-24 14:58:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-24 20:58:22 --> 404 Page Not Found: CustomPage/346
ERROR - 2018-10-24 22:41:32 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-24 22:47:32 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-24 23:04:35 --> 404 Page Not Found: Home/index
ERROR - 2018-10-24 23:30:08 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-24 23:30:09 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-24 23:30:11 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-24 23:30:12 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-24 23:30:13 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-24 23:30:13 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-24 23:30:15 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-24 23:30:15 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-24 23:30:16 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-24 23:30:16 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-24 23:30:17 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-24 23:30:18 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-24 23:30:19 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-24 23:30:20 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-24 23:30:20 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-24 23:30:21 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-24 23:30:22 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-24 23:30:22 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-24 23:30:24 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-24 23:30:24 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-24 23:30:25 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-24 23:30:25 --> 404 Page Not Found: Https:/use.fontawesome.com
