<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-08 00:52:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 00:52:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 00:53:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 00:53:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 01:28:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 01:28:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 01:28:49 --> Could not find the language line "artists_overview"
ERROR - 2018-10-08 01:28:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 01:28:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 01:28:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 01:28:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 01:29:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 01:29:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 01:29:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 01:29:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 01:29:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 01:29:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 01:29:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 01:29:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 01:45:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 01:45:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 02:35:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 02:35:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 03:06:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 03:06:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 05:33:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 05:33:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 05:54:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 05:54:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 05:54:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 05:54:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 05:55:02 --> Could not find the language line "artists_overview"
ERROR - 2018-10-08 05:55:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 05:55:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 05:55:08 --> Could not find the language line "producers_overview"
ERROR - 2018-10-08 05:55:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 05:55:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 05:55:13 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-08 05:55:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 05:55:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 05:55:17 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-08 05:55:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 05:55:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 06:19:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 06:19:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 08:54:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 08:54:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 11:33:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 11:33:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 12:00:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 12:00:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 12:33:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 12:33:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 00:18:50 --> 404 Page Not Found: Home/index
ERROR - 2018-10-08 01:25:51 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 14:04:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 14:04:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 01:53:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 15:12:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 02:42:02 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 15:12:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 15:12:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 02:42:03 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 15:12:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 15:12:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 02:42:04 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 15:12:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 15:12:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 02:42:05 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 02:42:06 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 02:42:06 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 15:12:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 15:12:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 02:42:07 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-08 02:42:07 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-08 02:42:08 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 02:42:08 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 02:42:09 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 15:12:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 15:12:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 02:42:09 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-08 02:42:10 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 02:42:10 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-08 02:42:11 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-08 02:42:11 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 02:42:11 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 02:42:12 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 15:12:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 15:12:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 02:42:13 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-08 02:42:13 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 02:42:13 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-08 02:42:14 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-08 15:37:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 15:37:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 16:16:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 16:16:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 16:16:46 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-08 16:16:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 16:16:47 --> Could not find the language line "artists_overview"
ERROR - 2018-10-08 16:16:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 03:46:48 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 16:16:48 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-08 16:16:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 16:16:49 --> Could not find the language line "producers_overview"
ERROR - 2018-10-08 16:16:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 16:16:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 03:46:50 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 16:16:50 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-08 16:16:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 03:46:51 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 16:16:51 --> Could not find the language line "artists_overview"
ERROR - 2018-10-08 16:16:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 03:46:51 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-08 16:16:52 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-08 16:16:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 16:16:53 --> Could not find the language line "producers_overview"
ERROR - 2018-10-08 16:16:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 16:16:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:16:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 03:46:56 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 04:08:57 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-08 16:39:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 16:39:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 04:27:48 --> 404 Page Not Found: Get-started/index
ERROR - 2018-10-08 17:31:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 17:31:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 05:27:28 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 18:01:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 18:01:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 18:22:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 18:22:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 18:22:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 18:22:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 18:22:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 18:22:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 05:57:22 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 19:33:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 19:33:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 19:45:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 19:45:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 07:15:19 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-08 07:19:58 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-08 20:04:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:04:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 07:44:05 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 20:24:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:24:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 20:25:27 --> Could not find the language line "artists_overview"
ERROR - 2018-10-08 20:25:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:25:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 20:25:31 --> Could not find the language line "producers_overview"
ERROR - 2018-10-08 20:25:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:25:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 20:25:35 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-08 20:25:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:25:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 20:25:39 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-08 20:25:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:25:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 20:27:53 --> Could not find the language line "artists_overview"
ERROR - 2018-10-08 20:27:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:27:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 20:27:55 --> Could not find the language line "producers_overview"
ERROR - 2018-10-08 20:27:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:27:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 20:27:57 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-08 20:27:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:27:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 20:28:01 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-08 20:28:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 20:28:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 08:20:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 08:27:30 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-08 08:36:46 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2018-10-08 21:15:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 21:15:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 09:19:30 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-08 10:41:18 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 23:13:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-08 23:13:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-08 10:54:55 --> 404 Page Not Found: Start/artist
ERROR - 2018-10-08 10:58:48 --> 404 Page Not Found: Status/index
ERROR - 2018-10-08 11:41:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 12:06:50 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-08 12:41:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 12:54:27 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-08 13:00:55 --> 404 Page Not Found: Status/index
ERROR - 2018-10-08 13:01:03 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2018-10-08 13:01:07 --> 404 Page Not Found: _phpMyAdmin/scripts
ERROR - 2018-10-08 13:01:11 --> 404 Page Not Found: Admin/scripts
ERROR - 2018-10-08 13:01:14 --> 404 Page Not Found: Scripts/setup.php
ERROR - 2018-10-08 13:01:18 --> 404 Page Not Found: Pma/scripts
ERROR - 2018-10-08 13:20:48 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-08 14:38:13 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 16:21:46 --> 404 Page Not Found: Status/index
ERROR - 2018-10-08 17:05:56 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 17:31:43 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-08 19:48:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 21:00:04 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-08 21:40:55 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-08 21:40:55 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-08 21:57:58 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 21:58:00 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 21:58:12 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 21:58:14 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 21:58:15 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 21:58:15 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-08 21:58:21 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-08 21:58:21 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-08 21:58:23 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 21:58:24 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-08 21:58:25 --> 404 Page Not Found: Https:/recordtime.zendesk.com
