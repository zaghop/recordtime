<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-25 00:17:26 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:17:26 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:17:52 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-11-25 00:17:52 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:17:52 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:18:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:18:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:20:28 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:20:28 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:21:40 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:21:40 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:23:32 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:23:32 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:26:25 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:26:25 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:26:25 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:26:49 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:26:49 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:26:49 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:33:15 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:33:15 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:33:15 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:34:04 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:34:04 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:34:04 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:34:14 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:34:14 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:34:14 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:35:36 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:35:36 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:35:36 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:35:49 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:35:49 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:35:49 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:36:00 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:36:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:36:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:36:37 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:36:37 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:36:37 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:37:36 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:37:36 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:37:36 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:39:17 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:39:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:39:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:39:22 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:39:22 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:39:22 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:39:43 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:39:43 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:39:43 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:39:47 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:39:47 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:39:47 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:40:45 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:40:45 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:40:45 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:41:20 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:41:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:41:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:42:01 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:42:01 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:42:01 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:42:44 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:42:44 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:42:45 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:43:19 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:43:19 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:43:19 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:43:59 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:43:59 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:43:59 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:44:24 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:44:24 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:44:24 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:44:41 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:44:41 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:44:41 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:44:50 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:44:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:44:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:46:25 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:46:25 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:46:25 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:46:39 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:46:39 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:46:39 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:47:05 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:47:05 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:47:05 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:47:18 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:47:18 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:47:18 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:47:26 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:47:26 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:47:26 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:47:39 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:47:39 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:47:39 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:47:51 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:47:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:47:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:48:17 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:48:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:48:17 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:49:47 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:49:47 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:49:47 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:50:07 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:50:07 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:50:07 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:50:11 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:50:11 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:50:11 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 00:50:11 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 00:50:11 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 00:50:11 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:02:29 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:02:29 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:02:33 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:02:33 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:02:33 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:03:01 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:03:01 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:03:01 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:03:51 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:03:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:03:51 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:04:09 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:04:09 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:04:09 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:04:38 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:04:38 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:04:38 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:04:41 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:04:41 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:04:41 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:05:01 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:05:01 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:05:01 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:08:55 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:08:55 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:08:55 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:09:04 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:09:04 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:09:04 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:09:43 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:09:43 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:09:43 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:10:00 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:10:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:10:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:11:32 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model C:\xampp\htdocs\recordtime\system\core\Loader.php 344
ERROR - 2018-11-25 01:12:30 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:12:30 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:12:30 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:12:30 --> Severity: Error --> Call to undefined method User_model::artists_signup() C:\xampp\htdocs\recordtime\application\controllers\Website.php 1409
ERROR - 2018-11-25 01:16:21 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:16:21 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:16:21 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:16:21 --> Query error: Unknown column 'fisrtname' in 'field list' - Invalid query: INSERT INTO `tbl_user` (`type`, `email`, `fisrtname`, `lastname`, `password`, `city`, `genre`, `artist_work`, `soundcloud_link`, `submit`) VALUES ('1', 'prakash10kce@gmail.com', 'prakash', 'tank', 'admin123', 'ahmedabad', 'w', '2', '2', 'Finish')
ERROR - 2018-11-25 01:16:57 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:16:57 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:16:57 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:16:57 --> Query error: Unknown column 'fisrtname' in 'field list' - Invalid query: INSERT INTO `tbl_user` (`type`, `email`, `fisrtname`, `lastname`, `password`, `city`, `genre`, `artist_work`, `soundcloud_link`, `submit`) VALUES ('1', 'prakash10kce@gmail.com', 'prakash', 'tank', 'admin123', 'ahmedabad', 'w', '2', '2', 'Finish')
ERROR - 2018-11-25 01:16:59 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:16:59 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:16:59 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:17:16 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:17:16 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:17:16 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:17:16 --> Query error: Unknown column 'soundcloud_link' in 'field list' - Invalid query: INSERT INTO `tbl_user` (`type`, `email`, `firstname`, `lastname`, `password`, `city`, `genre`, `artist_work`, `soundcloud_link`, `submit`) VALUES ('1', 'prakash10kce@gmail.com', 'prakash', 'tank', 'admin123', 'ahmedabad', 'w', 'w', '2', 'Finish')
ERROR - 2018-11-25 01:17:54 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:17:54 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:17:54 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:17:54 --> Query error: Unknown column 'submit' in 'field list' - Invalid query: INSERT INTO `tbl_user` (`type`, `email`, `firstname`, `lastname`, `password`, `city`, `genre`, `artist_work`, `soundcloud_link`, `submit`) VALUES ('1', 'prakash10kce@gmail.com', 'prakash', 'tank', 'admin123', 'ahmedabad', 'w', 'w', '2', 'Finish')
ERROR - 2018-11-25 01:18:31 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:18:31 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:18:31 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:19:50 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:19:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:19:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:20:00 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:20:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:20:00 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:20:50 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:20:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:20:50 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:24:15 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:24:15 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:24:15 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 01:24:16 --> Could not find the language line "artists_signup"
ERROR - 2018-11-25 01:24:16 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 01:24:16 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 23:53:38 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-25 23:53:38 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-25 19:23:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-25 19:23:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-25 19:23:39 --> 404 Page Not Found: Uploads/company
ERROR - 2018-11-25 19:31:41 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 19:34:44 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-25 19:37:09 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 19:44:13 --> 404 Page Not Found: Artists/profile
ERROR - 2018-11-25 19:52:12 --> 404 Page Not Found: Artists/profile
ERROR - 2018-11-25 19:53:00 --> 404 Page Not Found: Artists/profile
ERROR - 2018-11-25 19:59:32 --> 404 Page Not Found: Website/artists_profile
ERROR - 2018-11-25 20:00:42 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:00:42 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:00:42 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:00:42 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:00:42 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:00:42 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:00:42 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:47 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:47 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:01:50 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-25 20:01:50 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-25 20:02:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-25 20:02:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-25 20:03:17 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-25 20:03:18 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-25 20:03:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:03:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:03:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:03:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:03:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:03:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:03:48 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:05:08 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:05:08 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:05:08 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:05:08 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:05:08 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:05:08 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:05:08 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:08:46 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:08:46 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:08:46 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:08:46 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:08:46 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:08:46 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:08:46 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:10:16 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:10:16 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:10:16 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:10:16 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:10:16 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:10:16 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-25 20:10:16 --> 404 Page Not Found: Artists/images
