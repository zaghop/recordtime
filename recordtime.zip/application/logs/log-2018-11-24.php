<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-24 01:36:28 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-24 01:36:28 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-24 01:36:36 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-24 01:36:36 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-24 01:37:37 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-24 01:37:37 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-24 01:37:56 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-24 01:37:56 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-24 01:39:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-24 01:39:20 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-24 01:39:27 --> Could not find the language line "producers_overview"
ERROR - 2018-11-24 01:39:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-24 01:39:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-24 01:39:31 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-11-24 01:39:31 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-24 01:39:31 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-24 01:39:48 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-11-24 01:39:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-24 01:39:48 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-24 01:40:27 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-11-24 01:40:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-11-24 01:40:27 --> Severity: Notice --> Undefined variable: locale C:\xampp\htdocs\recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-11-24 19:47:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:47:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:47:27 --> 404 Page Not Found: Uploads/company
ERROR - 2018-11-24 19:47:52 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:47:52 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:48:00 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:48:00 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:50:29 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:50:29 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:53:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:53:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:53:41 --> 404 Page Not Found: Artists/signup
ERROR - 2018-11-24 19:56:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 19:56:49 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 20:04:04 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:04:04 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:04:04 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:04:04 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:05:36 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:05:36 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:05:37 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:05:49 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:07:36 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:07:36 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:09:17 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:09:17 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:09:20 --> 404 Page Not Found: Artists/sign-up-2.html
ERROR - 2018-11-24 20:09:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:09:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:09:45 --> 404 Page Not Found: Artists/sign-up-2.html
ERROR - 2018-11-24 20:10:45 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:10:45 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:11:20 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:11:20 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:12:01 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:12:01 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:12:45 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:12:45 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:16:25 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:16:25 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:16:25 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:16:25 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:16:39 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:16:39 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:16:39 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:16:39 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:17:05 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:17:05 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:17:05 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:17:05 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:17:39 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:17:39 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:17:51 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:17:51 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:19:47 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:20:07 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:32:29 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 20:32:30 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-24 20:32:33 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:33:01 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:33:51 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:34:09 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:34:38 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:34:41 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:38:56 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:39:04 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:39:43 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:46:59 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:48:31 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:49:50 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:50:00 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:50:51 --> 404 Page Not Found: Artists/images
ERROR - 2018-11-24 20:54:16 --> 404 Page Not Found: Artists/images
