<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-16 00:14:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 00:14:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 00:14:48 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 00:14:48 --> Could not find the language line "producers_overview"
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 00:14:48 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 00:14:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 00:14:49 --> Could not find the language line "artists_overview"
ERROR - 2018-10-16 00:14:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 00:14:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 01:26:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 01:26:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 02:22:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 02:22:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 02:27:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 02:27:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 03:07:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 03:07:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 03:21:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 03:21:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 03:21:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 03:21:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 03:21:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 03:21:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 03:21:39 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 03:21:40 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 03:25:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 03:25:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 05:00:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 05:00:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 05:04:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 05:04:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 05:10:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 05:10:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 05:55:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 05:55:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 06:05:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 06:05:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 06:08:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 06:08:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 06:59:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 06:59:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 07:57:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 07:57:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 08:11:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 08:11:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 09:06:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 09:06:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 09:19:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 09:19:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 09:25:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 09:25:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 10:33:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 10:33:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 11:46:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 11:46:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 11:46:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 11:46:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 11:46:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 11:46:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 11:46:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 11:46:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 11:46:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 11:46:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 11:46:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 11:46:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 11:46:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 11:46:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 11:46:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 11:46:58 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 12:01:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 12:01:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 12:04:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 12:04:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 12:31:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 12:31:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 12:35:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 12:35:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 00:26:54 --> 404 Page Not Found: Item/8203200201
ERROR - 2018-10-16 00:36:35 --> 404 Page Not Found: Get-started/producer
ERROR - 2018-10-16 00:59:36 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-16 01:00:14 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-16 02:08:20 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-16 15:28:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 15:28:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 15:33:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 15:33:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 03:12:01 --> 404 Page Not Found: Start/artist
ERROR - 2018-10-16 16:34:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 16:34:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 16:34:04 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-16 16:34:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 16:34:04 --> Could not find the language line "artists_overview"
ERROR - 2018-10-16 16:34:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 04:04:05 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-16 16:34:05 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-16 16:34:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 16:34:06 --> Could not find the language line "producers_overview"
ERROR - 2018-10-16 16:34:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 16:34:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 04:04:07 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-16 16:34:08 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-16 16:34:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 04:04:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-16 16:34:09 --> Could not find the language line "artists_overview"
ERROR - 2018-10-16 16:34:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 04:04:09 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-16 16:34:10 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-16 16:34:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 16:34:10 --> Could not find the language line "producers_overview"
ERROR - 2018-10-16 16:34:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 16:34:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 16:34:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 04:04:14 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-16 05:04:54 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-16 05:13:33 --> 404 Page Not Found: CustomPage/356
ERROR - 2018-10-16 18:06:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 18:06:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 18:07:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 18:07:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 19:10:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 19:10:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 06:40:06 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-16 06:40:06 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-16 06:40:06 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-16 06:40:07 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-16 06:40:08 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-16 06:40:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-16 06:40:09 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-16 06:40:09 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-16 06:40:09 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-16 06:40:10 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-16 06:40:10 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-16 06:40:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-16 06:59:46 --> 404 Page Not Found: Start/studio-professional
ERROR - 2018-10-16 19:36:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 19:36:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 19:38:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 19:38:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 07:08:49 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-16 20:05:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 20:05:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 07:50:44 --> 404 Page Not Found: Pages-blog-posthtml/index
ERROR - 2018-10-16 08:15:06 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-16 08:48:27 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-16 21:42:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 21:42:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 09:28:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-16 21:58:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 21:58:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 09:28:28 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-16 09:28:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-16 21:58:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 21:58:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 09:28:30 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-16 09:28:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-16 21:58:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 21:58:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 09:28:32 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-16 09:28:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-16 21:58:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 21:58:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 09:28:35 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-16 10:08:04 --> 404 Page Not Found: CustomPage/346
ERROR - 2018-10-16 23:01:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 23:01:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 23:34:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 23:34:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 23:34:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-16 23:34:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-16 11:26:35 --> 404 Page Not Found: Get-started/songwriter
ERROR - 2018-10-16 13:12:19 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-16 13:22:59 --> 404 Page Not Found: Adstxt/index
ERROR - 2018-10-16 13:26:56 --> 404 Page Not Found: Item/5647100167
ERROR - 2018-10-16 13:26:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-16 13:27:56 --> 404 Page Not Found: Administrator/index.php
ERROR - 2018-10-16 14:46:28 --> 404 Page Not Found: Start/artist
ERROR - 2018-10-16 15:21:23 --> 404 Page Not Found: Home/index
ERROR - 2018-10-16 15:28:16 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-16 15:28:18 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-16 15:28:19 --> 404 Page Not Found: _phpMyAdmin/scripts
ERROR - 2018-10-16 15:28:20 --> 404 Page Not Found: Scripts/setup.php
ERROR - 2018-10-16 15:28:21 --> 404 Page Not Found: Pma/scripts
ERROR - 2018-10-16 15:28:22 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2018-10-16 18:34:04 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2018-10-16 18:34:05 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2018-10-16 19:35:44 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-16 19:35:46 --> 404 Page Not Found: Bea_wls_deployment_internal/index
ERROR - 2018-10-16 19:35:48 --> 404 Page Not Found: _phpMyAdmin/scripts
ERROR - 2018-10-16 19:35:51 --> 404 Page Not Found: Scripts/setup.php
ERROR - 2018-10-16 19:35:53 --> 404 Page Not Found: Pma/scripts
ERROR - 2018-10-16 19:35:56 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2018-10-16 21:12:45 --> 404 Page Not Found: Administrator/index.php
ERROR - 2018-10-16 22:00:01 --> 404 Page Not Found: Article/5635
ERROR - 2018-10-16 22:39:52 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-16 22:44:45 --> 404 Page Not Found: Scripts/setup.php
ERROR - 2018-10-16 22:44:46 --> 404 Page Not Found: Pma/scripts
ERROR - 2018-10-16 22:44:50 --> 404 Page Not Found: Xmlrpcphp/index
ERROR - 2018-10-16 23:13:12 --> 404 Page Not Found: Rg-erdrphp/index
