<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-29 00:07:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 00:07:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 00:19:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 00:19:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 01:00:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 01:00:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 01:35:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 01:35:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 03:05:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 03:05:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 03:54:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 03:54:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 05:28:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 05:28:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 05:37:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 05:37:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 06:13:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 06:13:35 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 08:54:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 08:54:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 09:22:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 09:22:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 09:22:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 09:22:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 09:22:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 09:22:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 09:22:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 09:22:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 09:22:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 09:22:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 09:22:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 09:22:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 09:22:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 09:22:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 09:22:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 09:22:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 10:56:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 10:56:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:06 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-29 11:00:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:06 --> Could not find the language line "artists_overview"
ERROR - 2018-10-29 11:00:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:07 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-29 11:00:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:07 --> Could not find the language line "producers_overview"
ERROR - 2018-10-29 11:00:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:09 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-29 11:00:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:10 --> Could not find the language line "artists_overview"
ERROR - 2018-10-29 11:00:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:11 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-29 11:00:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:12 --> Could not find the language line "producers_overview"
ERROR - 2018-10-29 11:00:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:00:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:00:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:06:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:06:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:19:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:19:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:30:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:30:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 11:31:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 11:31:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 12:01:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 12:01:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 12:28:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 12:28:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 00:04:21 --> 404 Page Not Found: Assets/stock
ERROR - 2018-10-29 13:04:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 13:04:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 00:34:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 00:34:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 00:34:49 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 13:23:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 13:23:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 00:55:53 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-29 13:28:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 13:28:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 13:44:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 13:44:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 01:29:13 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-29 14:01:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 14:01:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 14:01:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 14:01:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 14:42:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 14:42:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 02:12:07 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-29 02:12:07 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-29 02:12:07 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-29 02:12:08 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-29 02:12:08 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 02:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-29 02:12:09 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-29 02:12:09 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-29 02:12:09 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-29 02:12:10 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-29 02:12:10 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 02:12:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-29 15:13:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 15:13:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 15:13:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 15:13:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 03:24:18 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-29 04:36:22 --> 404 Page Not Found: Git/HEAD
ERROR - 2018-10-29 04:57:51 --> 404 Page Not Found: Artist/854199
ERROR - 2018-10-29 18:13:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 18:13:43 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 18:13:46 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-29 18:13:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 18:13:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 18:31:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 18:31:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 06:01:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 06:01:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 06:01:10 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 18:32:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 18:32:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 06:02:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 06:02:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 06:02:26 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 07:14:08 --> 404 Page Not Found: Plus/download.php
ERROR - 2018-10-29 07:14:09 --> 404 Page Not Found: Plus/ad_js.php
ERROR - 2018-10-29 07:14:10 --> 404 Page Not Found: Plus/read.php
ERROR - 2018-10-29 07:14:11 --> 404 Page Not Found: Include/dialog
ERROR - 2018-10-29 07:14:11 --> 404 Page Not Found: Data/cache
ERROR - 2018-10-29 07:14:12 --> 404 Page Not Found: Install/index.php.bak
ERROR - 2018-10-29 07:14:13 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2018-10-29 07:14:13 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2018-10-29 07:14:15 --> 404 Page Not Found: Indexphp/index
ERROR - 2018-10-29 19:44:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 19:44:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 19:46:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 19:46:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 19:46:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 19:46:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 07:16:24 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 19:47:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 19:47:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 07:17:07 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 07:17:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 07:17:08 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 19:51:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 19:51:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 20:09:41 --> Could not find the language line "artists_overview"
ERROR - 2018-10-29 20:09:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 20:09:41 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 20:34:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-29 20:34:59 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-29 08:23:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-29 08:23:38 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 10:21:25 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 10:50:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-29 13:20:43 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-29 13:54:03 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-29 14:27:23 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-29 14:34:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-29 14:34:46 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 14:37:44 --> 404 Page Not Found: CustomPage/342
ERROR - 2018-10-29 15:12:26 --> 404 Page Not Found: Assets/application-a2d272f3d9fc762dd8988f20805dd31b8c5560662f4b738060182fcbf4fed65d.js
ERROR - 2018-10-29 15:53:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-29 16:05:30 --> 404 Page Not Found: Get-started/artist
ERROR - 2018-10-29 16:14:52 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 16:14:53 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 16:14:55 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 16:15:01 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-29 16:15:02 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-29 16:15:02 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 16:15:03 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-29 16:15:04 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-29 16:15:04 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-29 16:15:05 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-29 16:15:05 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 16:15:07 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-29 16:15:07 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 16:15:08 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-29 16:15:08 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-29 16:15:09 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-29 16:15:09 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-29 16:15:10 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 16:15:11 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-29 16:15:11 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 16:15:12 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-29 16:15:12 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-29 16:35:39 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 16:35:41 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 16:35:43 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 16:35:43 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 16:35:43 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 16:42:52 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-29 19:15:25 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 19:15:28 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-29 19:15:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 19:15:32 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-29 19:15:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 20:12:59 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2018-10-29 20:13:12 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2018-10-29 20:13:22 --> 404 Page Not Found: Home/index
ERROR - 2018-10-29 20:49:53 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 20:49:54 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 20:49:54 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 22:02:00 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-29 22:28:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-29 22:28:28 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-29 23:00:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 23:00:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-29 23:00:40 --> 404 Page Not Found: Uploads/company
