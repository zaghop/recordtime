<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-18 00:05:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 00:05:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 01:05:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 01:05:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 01:12:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 01:12:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 01:36:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 01:36:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 02:10:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 02:10:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 02:17:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 02:17:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 03:49:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 03:49:36 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 04:10:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 04:10:18 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 05:52:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 05:52:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 06:13:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 06:13:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 07:19:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 07:19:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 09:05:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 09:05:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 09:19:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 09:19:20 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 11:10:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 11:10:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 11:10:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 11:10:32 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 11:21:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 11:21:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 13:19:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 13:19:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 13:28:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 13:28:15 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 01:48:07 --> 404 Page Not Found: Well-known/assetlinks.json
ERROR - 2018-10-18 02:12:23 --> 404 Page Not Found: Console/css
ERROR - 2018-10-18 02:12:28 --> 404 Page Not Found: Status/index
ERROR - 2018-10-18 02:46:54 --> 404 Page Not Found: Get-started/index
ERROR - 2018-10-18 15:22:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 15:22:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 15:31:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 15:31:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 15:53:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 15:53:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 03:25:48 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-18 16:12:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 16:12:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 04:23:57 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-18 04:32:18 --> 404 Page Not Found: Assets/stock
ERROR - 2018-10-18 04:50:46 --> 404 Page Not Found: Get-started/artist
ERROR - 2018-10-18 05:02:04 --> 404 Page Not Found: CustomPage/342
ERROR - 2018-10-18 17:32:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 17:32:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 18:13:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 18:13:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 18:13:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 18:13:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 18:13:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 18:13:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 05:43:26 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2018-10-18 18:13:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 18:13:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 18:13:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 18:13:30 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 05:43:32 --> 404 Page Not Found: User/register
ERROR - 2018-10-18 06:12:57 --> 404 Page Not Found: Get-started/index
ERROR - 2018-10-18 20:52:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 20:52:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 21:31:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 21:31:37 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 09:12:11 --> 404 Page Not Found: Console/css
ERROR - 2018-10-18 09:12:12 --> 404 Page Not Found: Status/index
ERROR - 2018-10-18 10:09:19 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-18 10:16:34 --> 404 Page Not Found: CustomPage/346
ERROR - 2018-10-18 23:01:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 23:01:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 23:01:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 23:01:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 23:49:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-18 23:49:57 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-18 11:51:14 --> 404 Page Not Found: Pages-blog-posthtml/index
ERROR - 2018-10-18 12:37:36 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-18 12:37:41 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-18 12:38:38 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-18 12:38:47 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-18 13:46:49 --> 404 Page Not Found: Start/producer
ERROR - 2018-10-18 13:50:57 --> 404 Page Not Found: Home/index
ERROR - 2018-10-18 14:14:05 --> 404 Page Not Found: Console/css
ERROR - 2018-10-18 14:14:07 --> 404 Page Not Found: Status/index
ERROR - 2018-10-18 14:29:46 --> 404 Page Not Found: VMhfZ/index
ERROR - 2018-10-18 14:29:50 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2018-10-18 14:29:57 --> 404 Page Not Found: User/register
ERROR - 2018-10-18 14:37:19 --> 404 Page Not Found: Console/css
ERROR - 2018-10-18 14:37:27 --> 404 Page Not Found: Status/index
ERROR - 2018-10-18 15:06:32 --> 404 Page Not Found: Terms/index
ERROR - 2018-10-18 15:54:40 --> 404 Page Not Found: Cms/editor
ERROR - 2018-10-18 15:54:40 --> 404 Page Not Found: Cms/editor
ERROR - 2018-10-18 15:54:40 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2018-10-18 15:54:41 --> 404 Page Not Found: Plugins/p_fckeditor
ERROR - 2018-10-18 15:54:41 --> 404 Page Not Found: Js/fckeditor
ERROR - 2018-10-18 15:54:42 --> 404 Page Not Found: Cms/fckeditor
ERROR - 2018-10-18 15:54:42 --> 404 Page Not Found: Editor/editor
ERROR - 2018-10-18 15:54:43 --> 404 Page Not Found: Admin/FCKeditor
ERROR - 2018-10-18 15:54:43 --> 404 Page Not Found: Editor/filemanager
ERROR - 2018-10-18 15:54:44 --> 404 Page Not Found: Sites/all
ERROR - 2018-10-18 15:54:44 --> 404 Page Not Found: HTMLEditor/editor
ERROR - 2018-10-18 15:54:44 --> 404 Page Not Found: Ckeditor/filemanager
ERROR - 2018-10-18 15:54:45 --> 404 Page Not Found: Wysiwyg/fckeditor
ERROR - 2018-10-18 15:54:45 --> 404 Page Not Found: Editor/editor
ERROR - 2018-10-18 15:54:46 --> 404 Page Not Found: Admin/editor
ERROR - 2018-10-18 15:54:46 --> 404 Page Not Found: Modules/fckeditor
ERROR - 2018-10-18 15:54:47 --> 404 Page Not Found: Administrator/fckeditor
ERROR - 2018-10-18 15:54:47 --> 404 Page Not Found: Admin/editor
ERROR - 2018-10-18 16:27:20 --> 404 Page Not Found: Get-started/songwriter
ERROR - 2018-10-18 21:32:29 --> 404 Page Not Found: Wp-loginphp/index
ERROR - 2018-10-18 21:32:31 --> 404 Page Not Found: Blog/wp-login.php
ERROR - 2018-10-18 21:32:33 --> 404 Page Not Found: Wp/wp-login.php
ERROR - 2018-10-18 21:32:34 --> 404 Page Not Found: Wordpress/wp-login.php
