<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-23 21:03:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\recordtime\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-23 21:03:48 --> Unable to connect to the database
ERROR - 2018-11-23 21:07:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-23 21:07:37 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-23 21:07:37 --> 404 Page Not Found: Uploads/company
ERROR - 2018-11-23 21:07:56 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-23 21:07:56 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-23 21:08:00 --> 404 Page Not Found: Login/index
ERROR - 2018-11-23 21:08:31 --> 404 Page Not Found: Admin/home
ERROR - 2018-11-23 21:09:20 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-23 21:09:20 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-23 21:09:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-23 21:09:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-23 21:09:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-11-23 21:10:15 --> 404 Page Not Found: Producers/signup
