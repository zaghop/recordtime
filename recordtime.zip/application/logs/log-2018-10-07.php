<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-07 00:03:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 00:03:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 01:31:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 01:31:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 01:31:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 01:31:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 02:06:49 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 02:06:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 03:20:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 03:20:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 03:42:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 03:42:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 03:42:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 03:42:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 05:51:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 05:51:54 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 07:06:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 07:06:47 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 07:20:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 07:20:48 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 07:21:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 07:21:08 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 07:37:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 07:37:55 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 09:24:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 09:24:53 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 10:22:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 10:22:42 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 11:15:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 11:15:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 11:58:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 11:58:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 12:06:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 12:06:51 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 02:15:18 --> 404 Page Not Found: Licensephp/index
ERROR - 2018-10-07 16:01:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 16:01:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 16:08:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 16:08:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 17:07:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 17:07:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 17:07:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 17:07:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 17:07:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 17:07:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 05:05:46 --> 404 Page Not Found: Status/index
ERROR - 2018-10-07 05:05:55 --> 404 Page Not Found: Phpmyadmin/scripts
ERROR - 2018-10-07 05:05:56 --> 404 Page Not Found: _phpMyAdmin/scripts
ERROR - 2018-10-07 05:05:58 --> 404 Page Not Found: Admin/scripts
ERROR - 2018-10-07 05:05:59 --> 404 Page Not Found: Scripts/setup.php
ERROR - 2018-10-07 05:06:01 --> 404 Page Not Found: Pma/scripts
ERROR - 2018-10-07 18:03:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 18:03:34 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 18:03:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 18:03:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 05:33:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 05:34:03 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-07 18:09:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 18:09:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 05:39:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 05:39:27 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-07 05:39:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 18:12:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 18:12:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 05:42:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 05:42:11 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 18:59:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 18:59:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 06:29:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 06:29:33 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 06:29:33 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-07 19:11:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 19:11:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 06:41:05 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 06:41:07 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 19:11:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 19:11:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 06:41:13 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 06:41:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 06:41:18 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-07 06:41:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-07 06:41:25 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-07 06:42:11 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-07 06:42:47 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-07 19:13:31 --> Could not find the language line "artists_overview"
ERROR - 2018-10-07 19:13:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 19:13:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 06:43:42 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 19:15:01 --> Could not find the language line "artists_overview"
ERROR - 2018-10-07 19:15:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 19:15:01 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 06:45:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 07:20:25 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-07 20:23:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 20:23:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 08:44:48 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-07 21:28:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 21:28:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 22:38:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 22:38:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 22:39:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 22:39:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 22:54:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 22:54:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 11:09:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-07 23:55:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-07 23:55:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-07 12:58:34 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:58:35 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:58:35 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:58:36 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:58:38 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-07 12:58:50 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:58:50 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:58:51 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:58:57 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:11 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:12 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:14 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:14 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:14 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 12:59:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 13:46:40 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 16:35:12 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-07 16:44:53 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-07 17:03:35 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 17:03:36 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 17:03:36 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 17:03:36 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 17:13:18 --> 404 Page Not Found: Get-started/index
ERROR - 2018-10-07 18:22:26 --> 404 Page Not Found: Apple-icon-180x180png/index
ERROR - 2018-10-07 18:22:27 --> 404 Page Not Found: Apple-icon-180x180png/index
ERROR - 2018-10-07 19:06:48 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 20:25:43 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-07 22:58:24 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-07 23:31:02 --> 404 Page Not Found: WXcUZ/index
