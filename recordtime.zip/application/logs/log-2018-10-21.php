<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-21 01:00:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 01:00:00 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 01:25:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 01:25:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 01:27:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 01:27:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 03:27:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 03:27:29 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 03:59:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 03:59:19 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 04:48:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 04:48:38 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 04:49:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 04:49:56 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 05:28:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 05:28:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 11:26:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 11:26:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 11:26:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 11:26:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 11:38:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 11:38:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 12:33:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 12:33:45 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 00:04:21 --> 404 Page Not Found: Article/5635
ERROR - 2018-10-21 00:04:28 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-21 00:04:36 --> 404 Page Not Found: Home/index
ERROR - 2018-10-21 12:34:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 12:34:44 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 12:34:52 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-21 12:34:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 12:34:52 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 12:35:02 --> Could not find the language line "artists_overview"
ERROR - 2018-10-21 12:35:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 12:35:02 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 12:35:10 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-21 12:35:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 12:35:10 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 12:35:17 --> Could not find the language line "producers_overview"
ERROR - 2018-10-21 12:35:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 12:35:17 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 00:05:24 --> 404 Page Not Found: Home/index
ERROR - 2018-10-21 00:16:00 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-21 12:57:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 12:57:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 14:33:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 14:33:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 02:42:54 --> 404 Page Not Found: Start/songwriter
ERROR - 2018-10-21 15:14:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:14:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 15:14:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:14:03 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 02:44:04 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 15:14:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:14:04 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 02:44:05 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 15:14:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:14:05 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 02:44:06 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 15:14:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:14:07 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 02:44:07 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-21 02:44:08 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-21 02:44:08 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 15:14:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:14:09 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 02:44:09 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-21 02:44:10 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-21 02:44:10 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-21 02:44:11 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-21 02:44:11 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 15:14:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:14:12 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 02:44:12 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-21 02:44:13 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 02:44:13 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-21 02:44:14 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-21 02:44:14 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-21 02:44:15 --> 404 Page Not Found: Https:/oss.maxcdn.com
ERROR - 2018-10-21 02:44:15 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 15:14:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:14:16 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 02:44:17 --> 404 Page Not Found: Https:/ajax.googleapis.com
ERROR - 2018-10-21 02:44:17 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 02:44:18 --> 404 Page Not Found: Https:/maxcdn.bootstrapcdn.com
ERROR - 2018-10-21 02:44:18 --> 404 Page Not Found: Https:/use.fontawesome.com
ERROR - 2018-10-21 15:42:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:42:46 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 15:50:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 15:50:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 16:00:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 16:00:06 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 17:02:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 17:02:50 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 17:25:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 17:25:11 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 19:28:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:21 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 19:28:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 19:28:22 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-21 19:28:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 19:28:22 --> Could not find the language line "artists_overview"
ERROR - 2018-10-21 19:28:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:22 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 06:58:23 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 19:28:23 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-21 19:28:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:23 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 19:28:24 --> Could not find the language line "producers_overview"
ERROR - 2018-10-21 19:28:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 19:28:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:24 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 06:58:24 --> 404 Page Not Found: Https:/recordtime.zendesk.com
ERROR - 2018-10-21 19:28:25 --> Could not find the language line "artists_how_it_works"
ERROR - 2018-10-21 19:28:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:25 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 06:58:25 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-21 19:28:26 --> Could not find the language line "artists_overview"
ERROR - 2018-10-21 19:28:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:26 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 06:58:27 --> 404 Page Not Found: Artists/overview
ERROR - 2018-10-21 19:28:27 --> Could not find the language line "producers_how_it_works"
ERROR - 2018-10-21 19:28:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 19:28:27 --> Could not find the language line "producers_overview"
ERROR - 2018-10-21 19:28:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 19:28:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 19:28:28 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 06:58:31 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-21 20:28:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 20:28:31 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 20:29:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 20:29:33 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 08:11:27 --> 404 Page Not Found: Item/8203200201
ERROR - 2018-10-21 08:18:12 --> 404 Page Not Found: Start/artist
ERROR - 2018-10-21 21:32:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 21:32:13 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 09:35:30 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-21 22:18:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 22:18:14 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 10:08:50 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-21 23:28:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 8
ERROR - 2018-10-21 23:28:27 --> Severity: Notice --> Undefined variable: locale /nfs/c12/h01/mnt/225778/domains/recordtime.com/html/application/views/themes/recordtime/scripts.php 9
ERROR - 2018-10-21 13:14:45 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-21 13:14:46 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-21 13:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-21 13:14:46 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-21 13:14:46 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-21 13:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-21 13:14:46 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-21 13:14:46 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-21 13:14:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-21 13:14:47 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-21 13:14:47 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-21 13:14:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-21 13:22:50 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-21 13:22:50 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-21 13:22:50 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-21 13:22:51 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-21 13:22:52 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-21 13:22:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-21 13:22:52 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
ERROR - 2018-10-21 13:22:53 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
ERROR - 2018-10-21 13:22:53 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2018-10-21 13:22:53 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2018-10-21 13:22:53 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-21 13:22:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2018-10-21 14:44:18 --> 404 Page Not Found: 404testpage4525d2fdc/index
ERROR - 2018-10-21 14:44:18 --> 404 Page Not Found: 404javascriptjs/index
ERROR - 2018-10-21 14:47:46 --> 404 Page Not Found: Home/index
ERROR - 2018-10-21 16:56:07 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-21 17:15:34 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-21 17:45:52 --> 404 Page Not Found: Start/songwriter
ERROR - 2018-10-21 17:48:54 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-21 18:22:14 --> 404 Page Not Found: Rg-erdrphp/index
ERROR - 2018-10-21 19:13:56 --> 404 Page Not Found: Photo/418453918155
ERROR - 2018-10-21 19:44:57 --> 404 Page Not Found: Home/index
ERROR - 2018-10-21 21:09:08 --> 404 Page Not Found: Start/studio-professional
ERROR - 2018-10-21 21:50:20 --> 404 Page Not Found: Uploads/company
ERROR - 2018-10-21 22:24:51 --> 404 Page Not Found: Uploads/company
