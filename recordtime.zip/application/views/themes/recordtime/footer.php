<footer class="footer">
	<div class="text-center"><img src="<?= site_url().template_assets_path(); ?>/images/footer_logo.png" alt="Footer Logo" /></div>
    <div class="footer-menu">
    	<ul>
    		<li><a href="<?= site_url()?>">Home</a></li>
            <li><a href="<?= site_url('artists/overview')?>">Artists</a></li>
            <li><a href="<?= site_url('producers/overview')?>">Producers</a></li>
            <li><a href="https://recordtime.zendesk.com/hc/en-us/requests/new">Contact</a></li>
            <li><a href="#">Terms</a></li>
            <li><a href="#">Privacy</a></li>
            <li><a href="https://recordtime.zendesk.com/hc/en-us/requests/new">Help</a></li>
            <li><a href="#">Sign In</a></li>
            <li><a href="#">Sign Up</a></li>
        </ul>
    </div>
</footer>
<?php //echo date('Y'); ?><?php //echo _l('clients_copyright',get_option('companyname')); ?>
