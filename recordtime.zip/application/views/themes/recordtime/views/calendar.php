<div class="panel_s">
    <div class="panel-body">
        <div id="calendar"></div>
    </div>
</div>
<script>
var calendar_data = <?php echo json_encode($calendar_data); ?>
</script>
