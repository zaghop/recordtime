<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
ERROR - 2018-10-04 18:38:08 --> Severity: Error --> Class 'Clients_controller' not found D:\xampp56\htdocs\Priyank\Recordtime\application\controllers\Clients.php 4
ERROR - 2018-10-04 18:44:43 --> Severity: Notice --> Undefined property: Clients::$form_validation D:\xampp56\htdocs\Priyank\Recordtime\application\controllers\Clients.php 8
ERROR - 2018-10-04 18:44:43 --> Severity: Error --> Call to a member function set_error_delimiters() on null D:\xampp56\htdocs\Priyank\Recordtime\application\controllers\Clients.php 8
ERROR - 2018-10-04 18:45:37 --> 404 Page Not Found: /index
ERROR - 2018-10-04 18:45:38 --> 404 Page Not Found: /index
ERROR - 2018-10-04 18:46:10 --> 404 Page Not Found: /index
ERROR - 2018-10-04 18:46:45 --> Severity: Notice --> Undefined property: Website::$form_validation D:\xampp56\htdocs\Priyank\Recordtime\application\controllers\Website.php 8
ERROR - 2018-10-04 18:46:45 --> Severity: Error --> Call to a member function set_error_delimiters() on null D:\xampp56\htdocs\Priyank\Recordtime\application\controllers\Website.php 8
ERROR - 2018-10-04 18:46:47 --> Severity: Notice --> Undefined property: Website::$form_validation D:\xampp56\htdocs\Priyank\Recordtime\application\controllers\Website.php 8
ERROR - 2018-10-04 18:46:47 --> Severity: Error --> Call to a member function set_error_delimiters() on null D:\xampp56\htdocs\Priyank\Recordtime\application\controllers\Website.php 8
ERROR - 2018-10-04 18:47:03 --> Severity: Notice --> Undefined property: Website::$form_validation D:\xampp56\htdocs\Priyank\Recordtime\application\controllers\Website.php 8
ERROR - 2018-10-04 18:47:03 --> Severity: Error --> Call to a member function set_error_delimiters() on null D:\xampp56\htdocs\Priyank\Recordtime\application\controllers\Website.php 8
ERROR - 2018-10-04 18:47:10 --> Severity: Notice --> Undefined variable: language D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\perfex\head.php 49
ERROR - 2018-10-04 18:47:10 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\perfex\scripts.php 8
ERROR - 2018-10-04 18:47:10 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\perfex\scripts.php 9
ERROR - 2018-10-04 18:47:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-04 18:47:17 --> Severity: Notice --> Undefined variable: language D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\perfex\head.php 49
ERROR - 2018-10-04 18:47:17 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\perfex\scripts.php 8
ERROR - 2018-10-04 18:47:17 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\perfex\scripts.php 9
ERROR - 2018-10-04 18:47:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-04 19:12:47 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:12:47 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:12:47 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:09 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:13:09 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:13:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:10 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:10 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:26 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:13:26 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:13:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:14:16 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/logo.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:14:16 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:15:03 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:15:03 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:15:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:03 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:03 --> 404 Page Not Found: Images/logo.png
ERROR - 2018-10-04 19:15:03 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/logo.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:15:04 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:15:08 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:15:08 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:15:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:08 --> 404 Page Not Found: Images/logo.png
ERROR - 2018-10-04 19:15:08 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:15:09 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:15:16 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:15:16 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:15:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:16 --> 404 Page Not Found: Images/logo.png
ERROR - 2018-10-04 19:15:16 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:15:17 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:15:38 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:15:38 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:15:38 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/logo.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:15:39 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:16:00 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:16:00 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:16:00 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:16:00 --> 404 Page Not Found: Images/logo.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:16:01 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:16:05 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:16:05 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/logo.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:16:05 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:17:09 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:17:09 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:17:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:17:27 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:17:27 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:17:27 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:17:28 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:17:28 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:17:32 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:17:32 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/menu_icon.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/artist-menu-icon.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/producer-menu-icon.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/Secure.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/home_page_process.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/transparent.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/tailored.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/mobile-interaction-img.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/Anthony%20Johns.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/Kylie%20Glen.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/Andy%20Banks.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Images/intrection1.png
ERROR - 2018-10-04 19:17:32 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:18:15 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:18:15 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:18:15 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:18:15 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:18:15 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:18:16 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:18:27 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:18:27 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:18:27 --> 404 Page Not Found: Images/footer_logo.png
ERROR - 2018-10-04 19:18:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:18:27 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:19:08 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:19:08 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:19:08 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:19:09 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:19:13 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 8
ERROR - 2018-10-04 19:19:13 --> Severity: Notice --> Undefined variable: locale D:\xampp56\htdocs\Priyank\Recordtime\application\views\themes\recordtime\scripts.php 9
ERROR - 2018-10-04 19:19:13 --> 404 Page Not Found: Assets/themes
ERROR - 2018-10-04 19:19:14 --> 404 Page Not Found: Assets/themes
